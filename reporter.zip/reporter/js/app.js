const uploads = document.querySelector('#uploads');
const modalHead = document.querySelector('#head');0


//event listeners
events();
function events(){
    uploads.addEventListener('click', decide);
}

// functions
function decide(e){
    if(e.target.classList.contains('new')){
        modalHead.innerHTML='Upload Newest Content!';
    }
    else if (e.target.classList.contains('official')) {
        modalHead.innerHTML='Upload Official Content!';
    }
    else if (e.target.classList.contains('important')) {
        modalHead.innerHTML='Upload Important Content!';
    }
    else if (e.target.classList.contains('general')) {
            modalHead.innerHTML='Upload General Content!';
    }
    
}