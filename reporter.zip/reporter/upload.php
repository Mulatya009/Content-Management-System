<?php 

if($_POST) {
	// database connection
	 include('../connection.php');
	 
	// check db connection
	if($conn->connect_error) {
		die("Connection Failed : " . $conn->connect_error);
	} 
	else { 
		//echo "Successfully Connected";
	}

	$valid = array('success' => false, 'messages' => array());
	
    $reporter = "Name";
    $cat = $_POST['category'];
    $title = addslashes($_POST['title']);
	$description = addslashes($_POST['description']);
	$video_url = addslashes($_POST['video_url']);
	$status = "0";

	$type = explode('.', $_FILES['userImage']['name']);
	$type = $type[count($type) - 1];
	$url = '../uploads/' . uniqid(rand()) . '.' . $type;
	
	$type_banner = explode('.', $_FILES['userImage_banner']['name']);
	$type_banner = $type_banner[count($type_banner) - 1];
	$url_banner = '../uploads/' . uniqid(rand()) . '.' . $type_banner;

	if(in_array($type, array('jpg', 'jpeg', 'png', 'svg', 'gif', 'PNG')) && in_array($type_banner, array('jpg', 'jpeg', 'png', 'svg', 'gif', 'PNG'))) {
		if(is_uploaded_file($_FILES['userImage']['tmp_name']) && is_uploaded_file($_FILES['userImage_banner']['tmp_name'])) {
			if(move_uploaded_file($_FILES['userImage']['tmp_name'], $url) && move_uploaded_file($_FILES['userImage_banner']['tmp_name'], $url_banner)) {

				// insert into database by the category
				// breaking news.
				if($cat == 'breaking news'){
					$sql = "INSERT INTO breaking_news (reporter, title, description, video_url, image_square, image_banner, status) VALUES ('$reporter', '$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "breaking news published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}

				}
				// featured news
				elseif($cat == 'featured news'){
					$sql = "INSERT INTO featured_news (reporter, title, description, video_url, image_square, image_banner, status) VALUES ('$reporter', '$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "breaking news published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// latest music
				elseif($cat == 'latest music'){
                    $sql = "INSERT INTO latest_music (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";
    
    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// latest movies
				elseif($cat == 'latest movies'){
				    $sql = "INSERT INTO latest_movies (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "movie published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}	
				}
				// latest sports
				elseif($cat == 'latest sports'){
					$sql = "INSERT INTO latest_sports (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";
    
    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// new gallery
				elseif($cat == 'new gallery'){
				    $sql = "INSERT INTO new_gallery (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// funniest clips
				elseif($cat == 'funniest clips'){
					$sql = "INSERT INTO funniest_clips (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "clip published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// news
				elseif($cat == 'news'){
					$sql = "INSERT INTO news (reporter, title, description, video_url, square_image, banner_image, status) VALUES ('$reporter', '$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "news published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				} 
				// speaches
				elseif($cat == 'speaches'){
					$sql = "INSERT INTO speeches (title, description, video_url, square_image, banner_image, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "speech published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// briefs
				elseif($cat == 'briefs'){
					$sql = "INSERT INTO briefs (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

					if($conn->query($sql) === TRUE) {
						$valid['success'] = true;
						$valid['message'] = "brief published successifully.";
					} 
					else {
						$valid['success'] = false;
						$valid['message'] = "Error while uploading";
					}
				}
				// memos
				elseif($cat == 'memos'){
				    $sql = "INSERT INTO memos (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "memo published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}	
				}
				// music
				elseif($cat == 'music'){
					$sql = "INSERT INTO music (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// movie
				elseif($cat == 'movie'){
				    $sql = "INSERT INTO movie (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "movie published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}	
				}
				// clips
				elseif($cat == 'clips'){
					$sql = "INSERT INTO clips (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "clip published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// documentaries
				elseif($cat == 'documentaries'){
					$sql = "INSERT INTO documentary (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "documentary published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// gallery
				elseif($cat == 'gallery'){
					$sql = "INSERT INTO gallery (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// sports
				elseif($cat == 'sports'){
				    $sql = "INSERT INTO sports (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// dramma
				elseif($cat == 'dramma'){
					$sql = "INSERT INTO drama (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// dj mix
				elseif($cat == 'dj mix'){
					$sql = "INSERT INTO dj_rongo (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";
    
    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}
				// graduation
				elseif($cat == 'graduation'){
				    $sql = "INSERT INTO graduation (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}	
				}
				// orientation
				elseif($cat == 'orientation'){
				    $sql = "INSERT INTO orientation (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";

    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}	
				}
				// other events
				elseif($cat == 'memos'){
					$sql = "INSERT INTO other_events (title, description, video_url, image_square, image_banner, status) VALUES ('$title', '$description', '$video_url', '$url', '$url_banner', '$status')";
    
    				if($conn->query($sql) === TRUE) {
    					$valid['success'] = true;
    					$valid['message'] = "record published successifully.";
    				} 
    				else {
    					$valid['success'] = false;
    					$valid['message'] = "Error while uploading";
    				}
				}

				$conn->close();

			}
			else {
				$valid['success'] = false;
				$valid['message'] = "Error while uploading";
			}
		}
	}
	else {
		$valid['success'] = false;
		$valid['message'] = " Only upload (.jpg, .jpeg, .png, .svg, .gif, .PNG) files.";
	}

	echo json_encode($valid);

	// upload the file 
}