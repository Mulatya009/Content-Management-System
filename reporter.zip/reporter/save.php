<?php
    include('../connection.php');
	
	session_start();
	if($_POST['type']==1){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
        $password=$_POST['password'];
		$pass=$_POST['pass'];

		//$message = array('The Email is already taken', 'The two passwords do not match', 'Registration successiful', 'Failed to register', 'Wrong login credentials');
		
		$duplicate=mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
		if (mysqli_num_rows($duplicate)>0)
		{
			//$notify = $message[0];
			echo json_encode(array("statusCode"=>201));
		}
		else{
			$sql = "INSERT INTO `users`( `name`, `email`, `phone`, `password`) 
			VALUES ('$name','$email','$phone','$password')";
			if (mysqli_query($conn, $sql)) {
				//$notify = $message[2];
				echo json_encode(array("statusCode"=>200));
			} 
			else {
				//$notify = $message[3];
				echo json_encode(array("statusCode"=>201));
			}
		}
		mysqli_close($conn);
	}
	if($_POST['type']==2){
		$email=$_POST['email'];
		$password=$_POST['password'];
		$check=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' and password='$password'");
		if (mysqli_num_rows($check)>0)
		{
			$_SESSION['email']=$email;
			echo json_encode(array("statusCode"=>200));
		}
		else{
			echo json_encode(array("statusCode"=>201));
		}
		mysqli_close($conn);
	}
?>