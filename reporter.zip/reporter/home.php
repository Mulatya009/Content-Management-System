<!doctype html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <!-- Required meta tags -->
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="img/favicon.png" class="rounded-circle" type="image/png">
        <title>Admin</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="vendors/linericon/style.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
        <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
        <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
        <link rel="stylesheet" href="vendors/animate-css/animate.css">
        <link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
        <!-- main css -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
        <!-- App css -->
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" />
    </head>
    <style type="text/css">
        .col-2dot4,
        .col-sm-2dot4,
        .col-md-2dot4,
        .col-lg-2dot4,
        .col-xl-2dot4 {
            position: relative;
            width: 100%;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px;
        }
        .col-2dot4 {
            -webkit-box-flex: 0;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%;
            max-width: 20%;
        }
        @media (max-width: 540px) {
            .col-sm-2dot4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 100%;
                flex: 0 0 100%;
                max-width: 100%;
            }
        }
        @media (min-width: 540px) {
            .col-sm-2dot4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 100%;
                flex: 0 0 100%;
                max-width: 100%;
            }
        }
        @media (min-width: 720px) {
            .col-md-2dot4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 50%;
                flex: 0 0 50%;
                max-width: 50%;
            }
        }
        @media (min-width: 960px) {
            .col-lg-2dot4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 30%;
                flex: 0 0 30%;
                max-width: 30%;
            }
        }
        @media (min-width: 1140px) {
            .col-xl-2dot4 {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 20%;
                flex: 0 0 20%;
                max-width: 20%;
            }
        }
      
    </style>
    <body>
        
        <?php
            include('navbar.php');
        ?>
        <br><br><br>
         <!-- start page title -->
            <div class="row m-3">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <!-- <button type="button" class="btn btn-outline-success btn-rounded waves-effect waves-light" data-toggle="modal" data-target="#con-close-modal">Success</button> -->
                            <button type="button" class="btn btn-info waves-effect waves-light" data-toggle="modal" data-target="#myModal"><i class="mdi mdi-file-plus mr-1"></i>Add content</button>
                        </div>
                        <h4 class="page-title">Categories</h4>
                    </div>
                </div>
            </div>  
        
        <!--================Blog Area =================-->
         <div class="row mx-3">
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">breaking news</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->
           
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">featured news</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">latest music</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->
            
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">latest movies</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">latest sports</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">new gallery</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">funniest clips</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">news</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">speaches</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">briefs</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">memos</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">music</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">movies</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">clips</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">documentaries</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">gallery</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">sports</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">drama</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">dj mixes</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">graduation</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">orientation</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            <div class="col-2dot4 col-sm-2dot4 col-md-2dot4 col-lg-2dot4 col-xl-2dot4 col-md-6">
                <!-- Simple card -->
                <div class="card">
                    <img class="card-img-top img-fluid" src="img/instagram/Image-01.jpg" style"height: 180px; position: center;" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize">others</h5>
                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="btn btn-info waves-effect waves-light btn-block" data-toggle="modal" data-target="#con-close-modal"><i class="mdi mdi-arrow-right-circle mr-1"></i>View all</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end col -->  
            
            
        </div>
        <!--================Blog Area =================-->
        
        <!--================ start footer Area  =================-->	
        <?php
            include('footer.php');
        ?>
        <!--================ End footer Area  =================-->
        <!-- Button to Open the Modal -->
        <!-- The Modal -->
        <div class="modal modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title" style="color: pink;" id="head">Upload Content</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <!-- form -->
                        <form action="upload.php" method="POST" id="uploadImageForm">
                            <div class="form-group">
                                <label for="inputPassword4">Title</label>
                                <input type="text" name="title" class="form-control" id="inputPassword4" placeholder="Title" style="font-size: 12px; height: 45px;">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label for="inputPassword4">Category</label>
                                    <select name="category" class="form-control w-100" placeholder="Category">
                                        <option value=""></option>
                                        <option value="">Breaking news</option>
                                        <option value="featured ">Featured news</option>
                                        <option value="latest music">Latest music</option>
                                        <option value="latest movies">Latest movies</option>
                                        <option value="latest sports">Latest Sports</option>
                                        <option value="New gallery ">New gallery</option>
                                        <option value="funniest clips">Funniest clips</option>
                                        <option value="news">News</option>
                                        <option value="speaches">Speaches</option>
                                        <option value="briefs">Briefs</option>
                                        <option value="memos">Memos </option>
                                        <option value="music">Music</option>
                                        <option value="movie">Movie</option>
                                        <option value="clips">Clips</option>
                                        <option value="documentaries">Documentaries</option>
                                        <option value="gallery">Gallery</option>
                                        <option value="sports">Sports</option>
                                        <option value="drama">Dramma</option>
                                        <option value="dj mix">Dj mix</option>
                                        <option value="graduation">Graduation</option>
                                        <option value="orientation">Orientation</option>
                                        <option value="other events">Other events</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputAddress">Description</label>
                                <textarea name="description" class="form-control" id="inputAddress" rows="4" placeholder="Description"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Video upload</label>
                                <div class="input-group col-xs-12">
                                    <input type="text" name="video_url" class="form-control file-upload-info" placeholder="Upload video"  style="font-size: 12px; background-color: #fff; height: 45px;">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-md-4">
                                    <p style="font-size: 12px; color: #27367F;">Square thumbnail</p>
                                    <div id="kv-avatar-errors-2" class="center-block" style="width:800px;display:none"></div>
                                        <div class="kv-avatar center-block" style="width:200px">
                                        <input id="avatar-2" name="userImage" type="file" class="file-loading">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <p style="font-size: 12px; color: #27367F;">Banner thumbnail</p>
                                    <div id="kv-avatar-errors-3" class="center-block" style="width:1200px;display:none"></div>

                                        <div class="kv-avatar center-block" style="width:200px">
                                        <input id="avatar-3" name="userImage_banner" type="file" class="file-loading">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="submit" class="btn btn-info float-right">Publish</button>
        
                        </form>
                        <!-- form --> 
                    </div>
                </div>
            </div>
        </div>
        <!--sidebar-->
        <?php 
            include('../sidebar.php');
        ?>
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/app.js"></script>
        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/stellar.js"></script>
        <script src="vendors/lightbox/simpleLightbox.min.js"></script>
        <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
        <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
        <script src="vendors/isotope/isotope-min.js"></script>
        <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
        <script src="vendors/jquery-ui/jquery-ui.js"></script>
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/mail-script.js"></script>
        <script src="js/theme.js"></script>

        <!-- plugins -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- Plugins js-->
        <script src="../assets/libs/flatpickr/flatpickr.min.js"></script>
        <script src="../assets/libs/jquery-knob/jquery.knob.min.js"></script>
        <script src="../assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.resize.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.time.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.tooltip.min.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.selection.js"></script>
        <script src="../assets/libs/flot-charts/jquery.flot.crosshair.js"></script>
        <script src="../assets/fileinput/js/plugins/canvas-to-blob.min.js" type="text/javascript"></script>	
        <script src="../assets/fileinput/js/plugins/sortable.min.js" type="text/javascript"></script>	
        <script src="../assets/fileinput/js/plugins/purify.min.js" type="text/javascript"></script>
        <script src="../assets/fileinput/js/fileinput.min.js"></script>
        
        <!-- Dashboar 1 init js-->
        <script src="../assets/js/pages/dashboard-1.init.js"></script>
        
        <!-- App js-->
        <script src="../assets/js/app.min.js"></script>
        
        <script type="text/javascript">
        
        $("#avatar-2").fileinput({
        overwriteInitial: true,
        maxFileSize: 1500,
        showClose: false,
        showCaption: false,
        showBrowse: false,
        browseOnZoneClick: true,
        removeLabel: '',
        removeIcon: '<i class="fe-x" style="color: #fff;"></i>',
        removeTitle: 'Cancel or reset changes',
        elErrorContainer: '#kv-avatar-errors-2',
        msgErrorClass: 'alert alert-block alert-danger',
        defaultPreviewContent: '<img src="../assets/images/square.png" alt="Your Avatar" style="width:129px; border-radius: 5px;">',
        layoutTemplates: {main2: '{preview} {remove} {browse}'},
        allowedFileExtensions: ["jpg", "jpeg", "png", "svg", "gif", "PNG"]
        });
        
        
        $("#avatar-3").fileinput({
        overwriteInitial: true,
        maxFileSize: 1500,
        showClose: false,
        showCaption: false,
        showBrowse: false,
        browseOnZoneClick: true,
        removeLabel: '',
        removeIcon: '<i class="fe-x"></i>',
        removeTitle: 'Cancel or reset changes',
        elErrorContainer: '#kv-avatar-errors-3',
        msgErrorClass: 'alert alert-block alert-danger',
        defaultPreviewContent: '<img src="../assets/images/banner.png" alt="Your Avatar" style="width:309px; height: 125px; border-radius: 5px;">',
        layoutTemplates: {main2: '{preview} {remove} {browse}'},
        allowedFileExtensions: ["jpg", "jpeg", "png", "svg", "gif", "PNG"]
        });
        
        
        $(document).ready(function() {
        $("#uploadImageForm").unbind('submit').bind('submit', function() {
        
        var form = $(this);
        var formData = new FormData($(this)[0]);
        
        $.ajax({
        url: form.attr('action'),
        type: form.attr('method'),
        data: formData,
        dataType: 'json',
        cache: false,
        contentType: false,
        processData: false,
        async: false,
        success:function(responses) {
        if(responses.success == true) {
        
        
        $("#news_messages").html('<div class="alert alert-success alert-dismissible fade show" role="alert">'+
        '<span class="alert-icon"><i class="fe-check"></i></span>'+
        '<span class="alert-text"><strong>Thank you!,</strong> '+
        responses.message + '</span>'+
        
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '</div>');
        
        $('input[type="text"]').val('');
        $(".fileinput-remove-button").click();
        }
        else {
        
        $("#news_messages").html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
        '<span class="alert-icon"><i class="fe-x"></i></span>'+
        '<span class="alert-text"><strong>Sorry!,</strong> '+
        responses.message + '</span>'+
        
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '</div>');
        }
        }
        });
        
        return false;
        });
        });
        
        </script>
        <!-- plugins -->
    </body>
</html>